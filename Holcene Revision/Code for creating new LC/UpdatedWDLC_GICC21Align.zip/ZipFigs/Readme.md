#Red - removed layer (not included in header layer count)\
#Green - added layer (included in header layer count)\
#Grey - Unchanged from WD2014\
#Dashed Black - Bipolar Volcanic Links (from Sigl)